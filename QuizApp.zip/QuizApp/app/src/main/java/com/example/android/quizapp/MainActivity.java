package com.example.android.quizapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    double correctAnswers = 0;
    float totalQuestions = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    private void uncheckAllChildren(ViewGroup vg) {
        for (int i = 0; i < vg.getChildCount(); i++) {
            View v = vg.getChildAt(i);
            if (v instanceof CheckBox) {
                ((CheckBox) v).setChecked(false);
            }
        }
    }

	
    public void submitAnswersTapped(View v) {
    	Boolean answer3_choice1;
        Boolean answer3_choice2;
        Boolean answer3_choice3;
	Boolean answer3_choice4;
        correctAnswers += ((RadioButton) findViewById(R.id.q_one_a_rd)).isChecked() ? 1 : 0; //Question1
        answer3_choice1 = ((CheckBox) findViewById(R.id.q_two_a_cb)).isChecked();
        answer3_choice2 = ((CheckBox) findViewById(R.id.q_two_b_cb)).isChecked();
        answer3_choice3 = ((CheckBox) findViewById(R.id.q_two_c_cb)).isChecked();
	answer3_choice4 = ((CheckBox) findViewById(R.id.q_two_d_cb)).isChecked();
	if (!answer3_choice1 && !answer3_choice2 && answer3_choice3 && !answer3_choice4) {
            correctAnswers += 1;
        } else {
            correctAnswers += 0;
	}
        //correctAnswers += ((CheckBox) findViewById(R.id.q_two_c_cb)).isChecked() ? 1 : 0; //Question 2 C
        correctAnswers += ((RadioButton) findViewById(R.id.q_three_d_rd)).isChecked() ? 1 : 0; //Question 3
        correctAnswers += ((RadioButton) findViewById(R.id.q_four_b_rd)).isChecked() ? 1 : 0; //Question 4
        correctAnswers += ((EditText) findViewById(R.id.q_five_answer_txt)).getText().toString().equalsIgnoreCase("2014") ? 1 : 0; //Question 5

        Log.v("Five Answer: ", ((EditText) findViewById(R.id.q_five_answer_txt)).getText().toString());

        displayScore();
    }

        private void displayScore(){
            Log.v("Correct Answers", Double.toString(correctAnswers));
            double score = correctAnswers / totalQuestions * 100;
            score = Math.round(score);
            Log.v("Score: ", score  + "%");
            String scoreMessage = "Score: " + score + "%";
            Toast.makeText(MainActivity.this, scoreMessage, Toast.LENGTH_LONG).show();
            resetQuiz();
        }

        private void resetQuiz () {
            ((RadioGroup) findViewById(R.id.q_one_group_rd)).clearCheck(); //Question 1
            uncheckAllChildren((LinearLayout) findViewById(R.id.checkbox_question_cb)); //Question 2
            ((RadioGroup) findViewById(R.id.q_three_group_rd)).clearCheck(); //Question 3
            ((RadioGroup) findViewById(R.id.q_four_group_rd)).clearCheck(); //Question 4
            ((EditText) findViewById(R.id.q_five_answer_txt)).setText(""); //Question 5

            correctAnswers = 0;
        }

    }
